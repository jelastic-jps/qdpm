<?php

class qdPMConfiguration extends sfApplicationConfiguration
{
  public function configure()
  {
  }
}
