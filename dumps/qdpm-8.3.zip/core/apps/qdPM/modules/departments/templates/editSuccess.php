<h1><?php echo __('Edit Department') ?></h1>

<?php include_partial('form', array('form' => $form)) ?>
