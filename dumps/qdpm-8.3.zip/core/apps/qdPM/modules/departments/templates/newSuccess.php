<h1><?php echo __('New Department') ?></h1>

<?php include_partial('form', array('form' => $form)) ?>
