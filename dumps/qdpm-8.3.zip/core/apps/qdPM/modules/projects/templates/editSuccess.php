<h1><?php echo __('Edit Project') ?></h1>

<?php include_partial('form', array('form' => $form)) ?>
