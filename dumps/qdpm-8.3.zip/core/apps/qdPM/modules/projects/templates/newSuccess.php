<h1><?php echo __('New Project') ?></h1>

<?php include_partial('form', array('form' => $form)) ?>
