<h1><?php echo __('Edit Ticket') ?></h1>

<?php include_partial('form', array('form' => $form)) ?>
