<?php include_partial('form', array('form' => $form)) ?> 
  